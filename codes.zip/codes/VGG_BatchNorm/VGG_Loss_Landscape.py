import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from torch import nn
import numpy as np
import torch
import os
import random
from tqdm import tqdm as tqdm
from IPython import display

from models.vgg import VGG_A
from models.vgg import VGG_A_BatchNorm # you need to implement this network
from data.loaders import get_cifar_loader

import multiprocessing

multiprocessing.set_start_method('spawn', force=True)



# This function is used to calculate the accuracy of model classification
def get_accuracy(model, data_loader):
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for X, y in data_loader:
            X, y = X.to(device), y.to(device)
            outputs = model(X)
            _, predicted = torch.max(outputs.data, 1)
            total += y.size(0)
            correct += (predicted == y).sum().item()
    return correct / total

# Set a random seed to ensure reproducible results
def set_random_seeds(seed_value=0, device='cpu'):
    np.random.seed(seed_value)
    torch.manual_seed(seed_value)
    random.seed(seed_value)
    if device != 'cpu': 
        torch.cuda.manual_seed(seed_value)
        torch.cuda.manual_seed_all(seed_value)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


# We use this function to complete the entire
# training process. In order to plot the loss landscape,
# you need to record the loss value of each step.
# Of course, as before, you can test your model
# after drawing a training round and save the curve
# to observe the training
def train(model, optimizer, criterion, train_loader, val_loader, scheduler=None, epochs_n=30, best_model_path=None):
    model.to(device)
    learning_curve = [np.nan] * epochs_n
    train_accuracy_curve = [np.nan] * epochs_n
    val_accuracy_curve = [np.nan] * epochs_n
    max_val_accuracy = 0
    max_val_accuracy_epoch = 0

    batches_n = len(train_loader)
    losses_list = []
    grads = []
    for epoch in tqdm(range(epochs_n), unit='epoch'):
        print(epoch)
        if scheduler is not None:
            scheduler.step()
        model.train()

        loss_list = []  # use this to record the loss value of each step
        grad = []  # use this to record the loss gradient of each step
        learning_curve[epoch] = 0  # maintain this to plot the training curve
        total = 0
        correct = 0

        for data in train_loader:
            x, y = data
            x = x.to(device)
            y = y.to(device)
            optimizer.zero_grad()
            prediction = model(x)
            loss = criterion(prediction, y)
            # You may need to record some variable values here
            # if you want to get loss gradient, use
            # grad = model.classifier[4].weight.grad.clone()
            loss_list.append(loss.item())
            learning_curve[epoch] += loss.item()

            _, predicted = torch.max(prediction.data, 1)
            total += y.size(0)
            correct += (predicted == y).sum().item()

            loss.backward()
            optimizer.step()


        losses_list.append(loss_list)

        display.clear_output(wait=True)
        f, axes = plt.subplots(1, 2, figsize=(15, 3))

        learning_curve[epoch] /= batches_n
        axes[0].plot(learning_curve)

        # Test your model and save figure here (not required)
        # remember to use model.eval()
        ## --------------------
        # Add code as needed
        model.eval()
        train_accuracy = correct / total
        val_accuracy = get_accuracy(model, val_loader)
        train_accuracy_curve[epoch] = train_accuracy
        val_accuracy_curve[epoch] = val_accuracy
        learning_curve[epoch] /= batches_n
        
        # Update best model
        if val_accuracy > max_val_accuracy:
            max_val_accuracy = val_accuracy
            max_val_accuracy_epoch = epoch
            if best_model_path:
                torch.save(model.state_dict(), best_model_path)
        
        # Plot training progress
        display.clear_output(wait=True)
        fig, axes = plt.subplots(1, 2, figsize=(15, 5))
        
        axes[0].plot(learning_curve[:epoch+1])
        axes[0].set_title('Training Loss')
        axes[0].set_xlabel('Epoch')
        axes[0].set_ylabel('Loss')
        
        axes[1].plot(train_accuracy_curve[:epoch+1], label='Train')
        axes[1].plot(val_accuracy_curve[:epoch+1], label='Validation')
        axes[1].set_title('Accuracy')
        axes[1].set_xlabel('Epoch')
        axes[1].set_ylabel('Accuracy')
        axes[1].legend()
        
        plt.tight_layout()
        plt.savefig(os.path.join(figures_path, f'training_progress_epoch_{epoch+1}.png'))
        plt.close()
        ## --------------------

    return losses_list, grads




# Use this function to plot the final loss landscape,
# fill the area between the two curves can use plt.fill_between()
def plot_loss_landscape():
    ## --------------------
    # Add your code
    plt.figure(figsize=(10, 6))
    
    # Plot the loss landscape
    plt.plot(max_curve, label='Max Loss', color='red', alpha=0.7)
    plt.plot(min_curve, label='Min Loss', color='blue', alpha=0.7)
    plt.fill_between(range(len(max_curve)), min_curve, max_curve, color='gray', alpha=0.3)
    plt.xlabel('Training Steps')
    plt.ylabel('Loss')
    plt.title('Loss Landscape Comparison')
    plt.legend()
    plt.grid(True)
    
    # Save the figure
    plt.savefig(os.path.join(figures_path, 'loss_landscape_comparison.png'))
    plt.close()
    print(f"Loss landscape plot saved to {os.path.join(figures_path, 'loss_landscape_comparison.png')}")
    ## --------------------



if __name__ == '__main__':
    # ## Constants (parameters) initialization
    device_id = [0,1,2,3]
    num_workers = 4
    batch_size = 128

    # add our package dir to path 
    module_path = os.path.dirname(os.getcwd())
    home_path = module_path
    figures_path = ''#os.path.join(home_path, 'reports', 'figures')
    models_path = ''#os.path.join(home_path, 'reports', 'models')

    # Make sure you are using the right device.
    device_id = device_id
    os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"
    device = torch.device("cuda:{}".format(3) if torch.cuda.is_available() else "cpu")
    #print(device)
    #print(torch.cuda.get_device_name(3))


    # Initialize your data loader and
    # make sure that dataloader works
    # as expected by observing one
    # sample from it.
    train_loader = get_cifar_loader(train=True)
    val_loader = get_cifar_loader(train=False)
    #
    #for X, y in train_loader:
    #    print(f"Batch shape - X: {X.shape}, y: {y.shape}")
    #    print(f"Sample label values: {y[:5]}")
    #    # Visualize first image
    #    plt.imshow(X[0].permute(1, 2, 0))
    #    plt.title(f"Label: {y[0]}")
    #    plt.savefig(os.path.join(figures_path, 'sample_image.png'))
    #    plt.close()
    #    break



    # Train your model
    # feel free to modify
    epo = 5
    loss_save_path = figures_path
    grad_save_path = figures_path

    set_random_seeds(seed_value=2020, device=device)
    model = VGG_A()
    lr = 0.0005
    optimizer = torch.optim.Adam(model.parameters(), lr = lr)
    criterion = nn.CrossEntropyLoss()
    loss, grads = train(model, optimizer, criterion, train_loader, val_loader, epochs_n=epo, best_model_path='bestmodel.pth')
    np.savetxt(os.path.join(loss_save_path, 'loss.txt'), loss, fmt='%s', delimiter=' ')
    np.savetxt(os.path.join(grad_save_path, 'grads.txt'), grads, fmt='%s', delimiter=' ')

    # Maintain two lists: max_curve and min_curve,
    # select the maximum value of loss in all models
    # on the same step, add it to max_curve, and
    # the minimum value to min_curve
    min_curve = []
    max_curve = []
    ## --------------------
    # Add your code
    losses_array = np.array(loss)
    max_curve = np.max(losses_array, axis=0)
    min_curve = np.min(losses_array, axis=0)
    #
    ## --------------------

    plot_loss_landscape()
