'''
Models implementation and training & evaluating functions
'''

from . import vgg